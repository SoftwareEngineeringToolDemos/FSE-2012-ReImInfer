The aim of ReImInfer tool is to infer the purity of methods in java. 
A method is considered to be pure if it doesn't alter the state of the its input parameters and all the prestates reachable through the static fields.

In order to run the tool, Please follow the below steps.

1)Navigate to type-inference-0.1.2 folder on the desktop. This can be done using "cd /home/ubuntu/Desktop/type-inference-0.1.2/".    
2)Run the command "./binary/javai-reim <java-source-file>" , where <java-source-file> is the file on which you wish to run the tool. 
    For example if you want to run ReImInfer on inference-tests/CellClient.java, run "./binary/javai-reim inference-tests/CellClient.java".
3)After running the tool,the inference results are dumped to below 3 files in the same folder:
    new-result.jaif: The result in JAIF format containing fields, parameters and return values, but no local variables.
    new-result.csv: The purity inference result for all variables.
    new-pure-methods.csv: The pure methods inferred by the tool.

Note: The eclipse plugin of the tool is not working and it is suggested by the authors to use command line version of the tool instead. 

